package com.AbstractFactory;

public class MercedesTire extends Tire {
	
	public MercedesTire() {
		super("mercedes tire");
	}
}