package com.cognizant.designPatterns;

public interface IPhoneRepair {
	void ProcessPhoneRepair(String modelName);

}
